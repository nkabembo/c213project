<!DOCTYPE html>
<html>
<head>
<title>Main Page</title>
<style>
    
    body{
                background-color:#8A152D;
                font-family:Tahoma, Geneva, sans-serif;
    }
    nav{
        background-color:#EDC7B7;
        margin-top:10px;
    }
   
a{
 text-decoration:none;
 font-size:21px;
 }
 
ul{
list-style-type:none;
  margin: 10px;
  padding: 10px;
}
li{
display:inline;
margin:10px;
}
    img {
    height: auto;
    max-width: 100%;
    position: relative;
  border-radius: 20%;
  vertical-align: middle;
    border-style: none;
}
hr{
     border: 2px solid #AC3B61;
                margin-bottom: 25px; 
}
h1{
    display:inline;
    margin:0 auto;
    font-size: 60px;
    position: absolute;
    top: 50%;
    left: 50%;
    text-align: left;
    margin-right: -50%;
    transform: translate(-50%, -50%);
}
</style>
</head>
<body>
    <nav>
        <ul>
            <li><img src="l'artiste.png" width="50px" height="50px"></li>
            <li><a href="main.php">Home</a></li>
        <li><a href="registration.php">Create Account</a></li>
        <li><a href="signin.php">Login</a></li></ul>
        <hr>
    </nav>
   
    <h1><img src="l'artiste.png" width="50px" height="50px">Welcome to L'artiste</h1>

</body>

</html>

